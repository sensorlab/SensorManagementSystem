exports.xyz = function () {
    //
    console.log("xyz", this.a);
}