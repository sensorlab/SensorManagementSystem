Sensor Management System
==========================

This document provides administrator's manual. See user's manual for basic help.

Implementation
--------------

The application is implemented using the following technologies:

- [Node.js](http://nodejs.org/) for server-side business logic
- [Mongodb](http://www.mongodb.org/) for database (NoSQL type)
- HTML client with AJAX (JSON) calls to server

###Database collections (tables)

The system uses the following collections inside Mongodb database:

- users
- logins
- components
- clusters
- nodes
- history
- sensor_history

###Production commands

To run the system, use the following command line

	node top.js

This will start the web server, by default running on port 3000. To see other options, run command line:

	node top.js help


To run scan of all clusters and their nodes, run:

	node top.js scan

###For development only

The following command should only be run in development environment, since they change the data inside the system.

To clear database data (for **development purposes**), run:

	node top.js clean

To fill database with dummy data (for **development purposes**), run:

	node top.js fill_dummy_data

To dump database data to console (for **development purposes**), run:

	node top.js dump



Technicalities
--------------

###Zigbee network

This type of network has some specifics:

- Communicates over "REST-like" API - not strictly REST but close enough.
- Only one call to any function is permitted at the time
	- This means there will often be "COMMUNICATION IN PROGRESS" errors because of concurrency collisions
- Gateway node 
	- must exist (it is added automatically when cluster of this type is defined)
	- has network address 0 (system doesn't prohibit you to change it later)

